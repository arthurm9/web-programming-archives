// c�digo JavaScript
alert("Javascript");
